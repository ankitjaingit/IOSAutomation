package utilities;

import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class Utilities_IOS {
	IOSDriver<IOSElement>  driver;

	public Utilities_IOS(IOSDriver<IOSElement> driver)
	{
		this.driver=driver;
	}

	
	public void scrollToText(String text)
	{
		 	JavascriptExecutor js = (JavascriptExecutor) driver;
	        HashMap scrollObject = new HashMap<>();
	        scrollObject.put("predicateString", "value == '" + text + "'");
	        scrollObject.put("direction", "down");
	        js.executeScript("mobile: scroll", scrollObject);
		
	}
}
