package DB_IOS_Tests;

import java.io.IOException;

import org.testng.annotations.BeforeSuite;

import base.base_IOS;


public class ClearNode extends base_IOS {
	
	@BeforeSuite
	public void ClearNode() throws IOException {
		
		System.out.println("Inside BeforeTest");
		String[] command = { "/usr/bin/killall", "-KILL","node" };
		Runtime.getRuntime().exec(command);
		System.out.println("Command executed");

		
	}

}
