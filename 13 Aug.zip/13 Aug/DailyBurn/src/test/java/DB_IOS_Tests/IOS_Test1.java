package DB_IOS_Tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import base.base_IOS;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import objectrepository.HomePage_IOS;



public class IOS_Test1 extends base_IOS{
	@Test
	public void IOSTest() throws IOException, InterruptedException {


		System.out.println(System.getProperty("user.dir") + "/src/main/java/globalproperty/global_IOS.properties");

		FileInputStream fis = new FileInputStream(
				System.getProperty("user.dir") + "/src/main/java/globalproperty/global_IOS.properties");

		Properties prop = new Properties();
		prop.load(fis);
		String appName = (String) prop.getProperty("appName");
		System.out.println("appName is :" +appName);

		service =startServer();

		IOSDriver<IOSElement> driver = capabilities(appName);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		HomePage_IOS h = new HomePage_IOS(driver); 

		h.getButtonsfield().click(); 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().back();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.quit();
		stopServer();


	}

}