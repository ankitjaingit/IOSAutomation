package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class base_IOS {

	protected AppiumDriverLocalService service;
	private AppiumServiceBuilder builder;
	public static IOSDriver<IOSElement> driver;



	public AppiumDriverLocalService startServer() {


		// //Set Capabilities 
		//		cap = new DesiredCapabilities();
		//		  cap.setCapability("noReset", "false"); // // //Build the Appium service //
		//		  builder = new AppiumServiceBuilder(); 
		//		  builder.withIPAddress("127.0.0.1");
		//		  builder.usingPort(4723); 
		//		  builder.withCapabilities(cap);
		//		  builder.withArgument(GeneralServerFlag.SESSION_OVERRIDE);
		//		  builder.withArgument(GeneralServerFlag.LOG_LEVEL,"error");
		//		  //builder.withAppiumJS(new File("/usr/local/lib/node_modules/appium/build/lib/main.js")); //
		//		  builder.build();



		service = AppiumDriverLocalService
				.buildService(new AppiumServiceBuilder() 
						.usingDriverExecutable(new File("/usr/local/bin/node")) 
						.withAppiumJS(new File("/usr/local/lib/node_modules/appium/bin/appium.js"))
						.withIPAddress("127.0.0.1").usingPort(4723));

		service = AppiumDriverLocalService.buildService(builder);
		service.start();

		int port = 4723;
		if(!checkIfServerIsRunnning(port)) {
			//Start the server with the builder
			service = AppiumDriverLocalService.buildService(builder);
			service.start();
		}
		else {
			System.out.println("Appium Server already running on Port - " + port);
		}
		return service;


	}

	public void stopServer() {
		service.stop();
	}

	public boolean checkIfServerIsRunnning(int port) {

		boolean isServerRunning = false;
		ServerSocket serverSocket;
		try {
			serverSocket = new ServerSocket(port);
			serverSocket.close();
		} catch (IOException e) {
			//If control comes here, then it means that the port is in use
			isServerRunning = true;
		} finally {
			serverSocket = null;
		}
		return isServerRunning;
	}	



	public static IOSDriver<IOSElement> capabilities(String appName) throws IOException, InterruptedException {



		System.out.println(System.getProperty("user.dir") + "/src/main/java/globalproperty/global_IOS.properties");

		FileInputStream fis = new FileInputStream(
				System.getProperty("user.dir") + "/src/main/java/globalproperty/global_IOS.properties");

		Properties prop = new Properties();
		prop.load(fis);

		String PLATFORM_NAME=(String) prop.get("PLATFORM_NAME");
		System.out.println("PLATFORM NAME: "+PLATFORM_NAME);

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, PLATFORM_NAME);
		//capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");

		String PLATFORM_VERSION=(String) prop.get("PLATFORM_VERSION");
		System.out.println("PLATFORM VERSION : "+PLATFORM_VERSION);
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, PLATFORM_VERSION);
		//capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1");
		//capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.4.1");

		String AUTOMATION_NAME=(String) prop.get("AUTOMATION_NAME");
		System.out.println(" AUTOMATION NAME : "+AUTOMATION_NAME);
		// capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");

		String device=(String) prop.get("DEVICE_NAME");
		System.out.println("Device Name: "+device);
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, device);
		//capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone Simulator");
		//capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Diaspark's iPhone");

		capabilities.setCapability("useNewWDA", true);
		capabilities.setCapability("xcodeOrgId", "C5QA7FJ674");
		capabilities.setCapability("xcodeSigningId", "iPhone Developer");


		String udid=(String) prop.get("udid");
		System.out.println("udid : "+udid);
		capabilities.setCapability(MobileCapabilityType.UDID, udid);
		//capabilities.setCapability(MobileCapabilityType.UDID,"CD0B143C-7B27-44BC-ADC6-CFFB31DD11EB");
		//capabilities.setCapability(MobileCapabilityType.UDID, "7a15ea7c3b777c26c7d0fa2ff232bed0c169b264");

		capabilities.setCapability("updatedWDABundleId", "com.diaspark.inhouseprofile");
		capabilities.setCapability("bundleId", "com.UICatalogtestapp112");
		//capabilities.setCapability(MobileCapabilityType.APP, "/Users/nyt/Desktop/UICatalog_ankit/UICatalog.app");
		capabilities.setCapability(MobileCapabilityType.APP,"/Users/nyt/Desktop/UICatalog_ankit/Sim/UICatalog.app");


		IOSDriver iosDriver = new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		iosDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return iosDriver;
	}	


	public static void getScreenshot(String s) throws IOException { 
		File scrfile= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrfile,new
				File(System.getProperty("user.dir")+"\\"+s+".png"));

	}






	//		String PLATFORM_NAME=(String) prop.get("PLATFORM_NAME");
	//		System.out.println("PLATFORM NAME: "+PLATFORM_NAME);
	//		
	//		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, PLATFORM_NAME);
	//		//capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
	//		//capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
	//		
	//		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1");
	//		//capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.4.1");
	//
	//		// capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
	//		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
	//
	//		String device=(String) prop.get("DEVICE_NAME");
	//		System.out.println("Device Name: "+device);
	//		//String device = System.getProperty("deviceName");
	//		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, device);
	//		//capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone Simulator");
	//		//capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Diaspark's iPhone");
	//
	//		capabilities.setCapability("useNewWDA", true);
	//		capabilities.setCapability("xcodeOrgId", "C5QA7FJ674");
	//		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
	//
	//
	//		String udid=(String) prop.get("udid");
	//		capabilities.setCapability(MobileCapabilityType.UDID, udid);
	//		//capabilities.setCapability(MobileCapabilityType.UDID,"CD0B143C-7B27-44BC-ADC6-CFFB31DD11EB");
	//		//capabilities.setCapability(MobileCapabilityType.UDID, "7a15ea7c3b777c26c7d0fa2ff232bed0c169b264");
	//
	//		capabilities.setCapability("updatedWDABundleId", "com.diaspark.inhouseprofile");
	//		capabilities.setCapability("bundleId", "com.UICatalogtestapp112");
	//		//capabilities.setCapability(MobileCapabilityType.APP, "/Users/nyt/Desktop/UICatalog_ankit/UICatalog.app");
	//		capabilities.setCapability(MobileCapabilityType.APP,"/Users/nyt/Desktop/UICatalog_ankit/Sim/UICatalog.app");
	//		//capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	//
	//
	//		IOSDriver iosDriver = new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
	//		iosDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	//		return iosDriver;


}









//public class base_IOS {
//	public static AppiumDriverLocalService service;
//	public static AppiumDriverLocalService driver;
//	public static IOSDriver<IOSElement> iosDriver;
//
//	
//	
//	
//	
//	
//	
//	
////	public AppiumDriverLocalService startServer() {
////		//
////		boolean flag = checkIfServerIsRunnning(4723);
////		if (!flag) {
////			
////			service = AppiumDriverLocalService
////					.buildService(new AppiumServiceBuilder()
////							.usingDriverExecutable(new File("/usr/local/bin/node"))
////							.withAppiumJS(
////									new File(
////											"/usr/local/lib/node_modules/appium/bin/appium.js"))
////							.withIPAddress("127.0.0.0").usingPort(4723));
////
////			service.start();
////		}
////		
////		
////	
////		return service;
////
////	}
//	
//	
//	
//
//	public static boolean checkIfServerIsRunnning(int port) {
//
//		boolean isServerRunning = false;
//		ServerSocket serverSocket;
//		try {
//			serverSocket = new ServerSocket(port);
//
//			serverSocket.close();
//		} catch (IOException e) {
//			// If control comes here, then it means that the port is in use
//			isServerRunning = true;
//		} finally {
//			serverSocket = null;
//		}
//		return isServerRunning;
//	}
//
//	
//
//	
////	public static IOSDriver<IOSElement> capabilities(String appName) throws IOException, InterruptedException {
////
////		FileInputStream fis = new FileInputStream(
////		System.getProperty("user.dir") + "\\src\\main\\java\\global\\property\\global_IOS.properties");
////		
////		Properties prop = new Properties();
////		prop.load(fis);
////
////		// TODO Auto-generated method stub
////		File appDir = new File("src");
////		File app = new File(appDir, (String) prop.get(appName));
////
////		DesiredCapabilities capabilities = new DesiredCapabilities();
////
////		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
////
////		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1");
////		//capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.4.1");
////
////		// capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
////		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
////
////		String device=(String) prop.get("device");
////		//String device = System.getProperty("deviceName");
////		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, device);
////		//capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Diaspark's iPhone");
////
////		capabilities.setCapability("useNewWDA", true);
////		capabilities.setCapability("xcodeOrgId", "C5QA7FJ674");
////		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
////
////		
////		String udid=(String) prop.get("udid");
////		capabilities.setCapability(MobileCapabilityType.UDID, udid);
////		//capabilities.setCapability(MobileCapabilityType.UDID,"CD0B143C-7B27-44BC-ADC6-CFFB31DD11EB");
////		//capabilities.setCapability(MobileCapabilityType.UDID, "7a15ea7c3b777c26c7d0fa2ff232bed0c169b264");
////
////		capabilities.setCapability("updatedWDABundleId", "com.diaspark.inhouseprofile");
////		capabilities.setCapability("bundleId", "com.UICatalogtestapp112");
////		//capabilities.setCapability(MobileCapabilityType.APP, "/Users/nyt/Desktop/UICatalog_ankit/UICatalog.app");
////		capabilities.setCapability(MobileCapabilityType.APP,"/Users/nyt/Desktop/UICatalog_ankit/Sim/UICatalog.app");
////		//capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
////
////		
////		iosDriver = new IOSDriver(new URL("http://127.0.0.0:4723/wd/hub"), capabilities);
////		iosDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
////		return iosDriver;
////	}
//
//
//	private static HttpCommandExecutor URL(String string) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	
////	public static void getScreenshot(String s) throws IOException { 
////		File scrfile= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
////		FileUtils.copyFile(scrfile,new
////		File(System.getProperty("user.dir")+"\\"+s+".png"));
////
////	}
//
//
//
//}
