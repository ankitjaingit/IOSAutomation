package objectrepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.base_IOS;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class HomePage_IOS {

	// 1. Is to call the driver object from testcase to Pageobject file

	//Concatenate driver
	public HomePage_IOS(IOSDriver<IOSElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}


	

	@iOSFindBy(xpath="\"//XCUIElementTypeApplication[@name=\\\"UICatalog\\\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[3]\").getText();")
	public IOSElement ActionSheet;

	
//	@iOSFindBy(Xpath="");
//	public IOSElement 



	//driver.findElementByXpath("//android.widget.TextView[@text='Preference']");






}
