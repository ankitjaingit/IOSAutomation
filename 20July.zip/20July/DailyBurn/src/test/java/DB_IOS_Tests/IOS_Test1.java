package DB_IOS_Tests;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import base.base_IOS;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import objectrepository.HomePage_IOS;



public class IOS_Test1 extends base_IOS{
	@Test
	public void IOSTest() throws IOException, InterruptedException {

		startServer();
		
		IOSDriver<IOSElement> driver = capabilities("UICatalog.app");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		HomePage_IOS h = new HomePage_IOS(driver);
		//h.ActionSheet.click();
		
		service.stop();
	}

}