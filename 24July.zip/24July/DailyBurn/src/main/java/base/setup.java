package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class setup {




	protected AppiumDriverLocalService service;
	private AppiumServiceBuilder builder;
	public static IOSDriver<IOSElement> driver;
	//Saucelabs releted
	public static final String USERNAME = "YOUR_USERNAME";
	public static final String ACCESS_KEY = "YOUR_ACCESS_KEY";
	public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:443/wd/hub";



	public AppiumDriverLocalService startServer() {



		service = AppiumDriverLocalService.buildDefaultService();
		service.start();

		//			service = AppiumDriverLocalService
		//					.buildService(new AppiumServiceBuilder() 
		//							.usingDriverExecutable(new File("/usr/local/bin/node")) 
		//							.withAppiumJS(new File("/usr/local/lib/node_modules/appium/bin/appium.js"))
		//							.withIPAddress("127.0.0.1").usingPort(4723));

		//			service = AppiumDriverLocalService.buildService(builder);
		//			service.start();

		//			int port = 4723;
		//			if(!checkIfServerIsRunnning(port)) {
		//				//Start the server with the builder
		//				service = AppiumDriverLocalService.buildService(builder);
		//				service.start();
		//			}
		//			else {
		//				System.out.println("Appium Server already running on Port - " + port);
		//			}
		return service;


	}

	public void stopServer() {
		service.stop();
	}

	public boolean checkIfServerIsRunnning(int port) {

		boolean isServerRunning = false;
		ServerSocket serverSocket;
		try {
			serverSocket = new ServerSocket(port);
			serverSocket.close();
		} catch (IOException e) {
			//If control comes here, then it means that the port is in use
			isServerRunning = true;
		} finally {
			serverSocket = null;
		}
		return isServerRunning;
	}	



	public static IOSDriver<IOSElement> capabilities(String appName) throws IOException, InterruptedException {



		System.out.println(System.getProperty("user.dir") + "/src/main/java/globalproperty/global_IOS.properties");

		FileInputStream fis = new FileInputStream(
				System.getProperty("user.dir") + "/src/main/java/globalproperty/global_IOS.properties");

		Properties prop = new Properties();
		prop.load(fis);

		DesiredCapabilities capabilities = new DesiredCapabilities();

		String PLATFORM_NAME=(String) prop.get("PLATFORM_NAME");
		System.out.println("PLATFORM NAME: "+PLATFORM_NAME);
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, PLATFORM_NAME);
		//capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");

		String PLATFORM_VERSION=(String) prop.get("PLATFORM_VERSION");
		System.out.println("PLATFORM VERSION : "+PLATFORM_VERSION);
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, PLATFORM_VERSION);
		//capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1");
		//capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.4.1");

		String AUTOMATION_NAME=(String) prop.get("AUTOMATION_NAME");
		System.out.println(" AUTOMATION NAME : "+AUTOMATION_NAME);
		// capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");

		String device=(String) prop.get("DEVICE_NAME");
		System.out.println("Device Name: "+device);
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, device);
		//capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone Simulator");
		//capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Diaspark's iPhone");

//		capabilities.setCapability("useNewWDA", true);
//		capabilities.setCapability("xcodeOrgId", "C5QA7FJ674");
//		capabilities.setCapability("xcodeSigningId", "iPhone Developer");


//		String udid=(String) prop.get("udid");
//		System.out.println("udid : "+udid);
//		capabilities.setCapability(MobileCapabilityType.UDID, udid);
		//capabilities.setCapability(MobileCapabilityType.UDID,"CD0B143C-7B27-44BC-ADC6-CFFB31DD11EB");
		//capabilities.setCapability(MobileCapabilityType.UDID, "7a15ea7c3b777c26c7d0fa2ff232bed0c169b264");

		capabilities.setCapability("updatedWDABundleId", "com.diaspark.inhouseprofile");
		capabilities.setCapability("bundleId", "com.UICatalogtestapp112");
		//capabilities.setCapability(MobileCapabilityType.APP, "/Users/nyt/Desktop/UICatalog_ankit/UICatalog.app");
		capabilities.setCapability(MobileCapabilityType.APP,"/Users/nyt/Desktop/UICatalog_ankit/Sim/UICatalog.app");
		capabilities.setCapability("appiumVersion", "1.5.3");
		
//Sample DC for saucelabs from search.
//			capabilities.setCapability("platformName", "iOS");
//	        capabilities.setCapability("deviceName", "iPhone 6");
//	        capabilities.setCapability("platformVersion", "8.4");
//	        capabilities.setCapability("app", "https://s3.amazonaws.com/appium/TestApp8.4.app.zip");
//	        capabilities.setCapability("browserName", "");
//	        capabilities.setCapability("deviceOrientation", "portrait");
//	        capabilities.setCapability("appiumVersion", "1.5.3");
		 //WebDriver driver = new IOSDriver(new URL(URL), capabilities);
		
		
		IOSDriver  iosDriver = new IOSDriver(new URL(URL), capabilities);
		iosDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return iosDriver;
	}	


	public static void getScreenshot(String s) throws IOException { 
		File scrfile= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrfile,new
				File(System.getProperty("user.dir")+"\\"+s+".png"));

	}














	//
	//	public static URL url;
	//	public static DesiredCapabilities capabilities;
	//	public static IOSDriver<IOSElement> driver;
	//
	//	//@Parameters({"appName"})
	////IOSDriver<IOSElement> capabilities(String appName)
	//	@Test
	//	public static IOSDriver<IOSElement> cap() throws IOException, InterruptedException {
	//
	//		System.out.println(System.getProperty("user.dir"));
	//		System.out.println(System.getProperty("user.dir") + "/src/main/java/globalproperty/global_IOS.properties");
	//
	////		FileInputStream fis = new FileInputStream(
	////				System.getProperty(("user.dir") + "/src/main/java/globalproperty/global_IOS.properties"));
	//// 
	////		Properties prop = new Properties();
	////		prop.load(fis);
	//
	//		// TODO Auto-generated method stub
	//		//		File appDir = new File("src");
	//		//		File app = new File(appDir, (String) prop.get(appName));
	//		//
	//		DesiredCapabilities capabilities = new DesiredCapabilities();
	//
	//		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
	//
	//		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1");
	//		//capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.4.1");
	//
	//		// capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
	//		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
	//
	//		//String device=(String) prop.get("DEVICE_NAME");
	//		//String device = System.getProperty("deviceName");
	//		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone Simulator");
	//		//capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, device);
	//		//capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Diaspark's iPhone");
	//
	//		capabilities.setCapability("useNewWDA", true);
	//		capabilities.setCapability("xcodeOrgId", "C5QA7FJ674");
	//		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
	//
	//
	//		//String udid=(String) prop.get("udid");
	//		//capabilities.setCapability(MobileCapabilityType.UDID, udid);
	//		capabilities.setCapability(MobileCapabilityType.UDID,"CD0B143C-7B27-44BC-ADC6-CFFB31DD11EB");
	//		//capabilities.setCapability(MobileCapabilityType.UDID, "7a15ea7c3b777c26c7d0fa2ff232bed0c169b264");
	//
	//		capabilities.setCapability("updatedWDABundleId", "com.diaspark.inhouseprofile");
	//		capabilities.setCapability("bundleId", "com.UICatalogtestapp112");
	//		//capabilities.setCapability(MobileCapabilityType.APP, "/Users/nyt/Desktop/UICatalog_ankit/UICatalog.app");
	//		capabilities.setCapability(MobileCapabilityType.APP,"/Users/nyt/Desktop/UICatalog_ankit/Sim/UICatalog.app");
	//		//capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	//
	//
	//		IOSDriver<IOSElement> iosDriver = new IOSDriver<IOSElement>(new URL("http://127.0.0.1:4725/wd/hub"), capabilities);
	//		iosDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	//		return iosDriver;
	//	}
	//
	//
	//
	//
	//	//	@BeforeSuite
	//	//	public void setupAppium() throws MalformedURLException {
	//	//		// 2
	//	//		final String URL_STRING = "http://127.0.0.1:4723/wd/hub";
	//	//		url = new URL(URL_STRING);
	//	//		
	//	//		
	//	//		
	//	//		// =========Capabilities for Real Device
	//	//
	//	//		capabilities = new DesiredCapabilities();
	//	//		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
	//	//		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1");
	//	//		//capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.4.1");
	//	//
	//	//		// capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
	//	//		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
	//	//		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone Simulator");
	//	//		//capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Diaspark's iPhone");
	//	//
	//	//		capabilities.setCapability("useNewWDA", true);
	//	//		capabilities.setCapability("xcodeOrgId", "C5QA7FJ674");
	//	//		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
	//	//		capabilities.setCapability(MobileCapabilityType.UDID,"CD0B143C-7B27-44BC-ADC6-CFFB31DD11EB");
	//	//		//capabilities.setCapability(MobileCapabilityType.UDID, "7a15ea7c3b777c26c7d0fa2ff232bed0c169b264");
	//	//
	//	//		capabilities.setCapability("updatedWDABundleId", "com.diaspark.inhouseprofile");
	//	//		capabilities.setCapability("bundleId", "com.UICatalogtestapp112");
	//	//		//capabilities.setCapability(MobileCapabilityType.APP, "/Users/nyt/Desktop/UICatalog_ankit/UICatalog.app");
	//	//		capabilities.setCapability(MobileCapabilityType.APP,"/Users/nyt/Desktop/UICatalog_ankit/Sim/UICatalog.app");
	//	//
	//	//		
	//	//		driver = new IOSDriver<IOSElement>(url, capabilities);
	//	//		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	//	//		driver.resetApp();
	//	//	}
	//
}
