package DB_IOS_Tests;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import base.setup;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import objectrepository.HomePage_IOS;



public class IOS_Test_SauceLabs extends setup{
	@Test
	public void IOSTest() throws IOException, InterruptedException {

		//service =startServer();
		
		IOSDriver<IOSElement> driver = capabilities("UICatalog.app");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		HomePage_IOS h = new HomePage_IOS(driver);
		//h.getActionSheet().click();
		//driver.navigate().back();
		//service.stop();
		h.getButtonsfield().click();
		driver.navigate().back();
		
	}

}