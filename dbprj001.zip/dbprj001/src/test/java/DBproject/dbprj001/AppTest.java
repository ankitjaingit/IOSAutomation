package DBproject.dbprj001;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.ClickAction;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class AppTest {
	public static URL url;
	public static DesiredCapabilities capabilities;
	public static IOSDriver<IOSElement> driver;

	// 1
	@BeforeSuite
	public void setupAppium() throws MalformedURLException {
		// 2
		final String URL_STRING = "http://127.0.0.1:4723/wd/hub";
		url = new URL(URL_STRING);

		// =========Capabilities for Real Device

		capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
		// capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.4.1");

		// capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
		// capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone
		// Simulator");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Diaspark's iPhone");

		capabilities.setCapability("useNewWDA", true);
		capabilities.setCapability("xcodeOrgId", "C5QA7FJ674");
		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
		capabilities.setCapability(MobileCapabilityType.UDID,"CD0B143C-7B27-44BC-ADC6-CFFB31DD11EB");
		//capabilities.setCapability(MobileCapabilityType.UDID, "7a15ea7c3b777c26c7d0fa2ff232bed0c169b264");

		capabilities.setCapability("updatedWDABundleId", "com.diaspark.inhouseprofile");
		capabilities.setCapability("bundleId", "com.UICatalogtestapp112");
		//capabilities.setCapability(MobileCapabilityType.APP, "/Users/nyt/Desktop/UICatalog_ankit/UICatalog.app");
		capabilities.setCapability(MobileCapabilityType.APP,"/Users/nyt/Desktop/UICatalog_ankit/Sim/UICatalog.app");

		// capabilities.setCapability("realDeviceLogger",
		// "/usr/local/lib/node_modules/deviceconsole/deviceconsole");

		// 4
		driver = new IOSDriver<IOSElement>(url, capabilities);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.resetApp();
	}

	// 5
	@AfterSuite
	public void uninstallApp() throws InterruptedException {
		driver.removeApp("UICatalog.ipa");
	}

	// 6
	@Test(enabled = true)
	public void myFirstTest() throws InterruptedException {driver.findElementsByAccessibilityId("action_sheets_button");

		String strVarText = driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UICatalog\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[3]").getText();
		System.out.println(" element text: " + strVarText);

		driver.findElementByXPath(
				"//XCUIElementTypeApplication[@name=\"UICatalog\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[3]")
					.click();

		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"UICatalog\"]\n" + "").click();

		driver.findElementByXPath(
				"//XCUIElementTypeApplication[@name=\"UICatalog\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[4]")
				.click();

		driver.findElementByXPath("//XCUIElementTypeButton[@name=\"UICatalog\"]\n" + "").click();
		
	}
}